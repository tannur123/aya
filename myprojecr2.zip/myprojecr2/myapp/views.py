from django.shortcuts import render
from .models import Post
import requests
from django.shortcuts import render


def index(request):
    api_key = '37d02307fccf16083b5956e93e6cc7da'
    city = request.GET.get('city', 'Almaty')
    
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric&lang=ru'
    
    response = requests.get(url)
    data = response.json()
    
    context = {}
    if data.get('cod') == 200:
        context = {
            'city': city,
            'temperature': data['main']['temp'],
            'description': data['weather'][0]['description'],
            'icon': data['weather'][0]['icon'],
        }
    else:
        context = {
            'error': 'Қала табылмады немесе қате болды.'
        }
    
    return render(request, 'myapp/index.html', context)