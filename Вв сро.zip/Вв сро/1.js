let cart = [];
let totalPrice = 0;

// Добавление товара в корзину
function addToCart(name, price) {
    cart.push({ name, price });
    totalPrice += price;

    document.getElementById("cart-count").innerText = cart.length;
    updateCart();
}

// Обновление отображения корзины
function updateCart() {
    let cartItems = document.getElementById("cart-items");
    cartItems.innerHTML = "";

    cart.forEach((item, index) => {
        cartItems.innerHTML += `
            <div class="cart-item">
                <span>${item.name} - $${item.price}</span>
                <button onclick="removeItem(${index})">X</button>
            </div>
        `;
    });

    document.getElementById("total-price").innerText = totalPrice;
}

// Удаление товара
function removeItem(index) {
    totalPrice -= cart[index].price;
    cart.splice(index, 1);

    document.getElementById("cart-count").innerText = cart.length;
    updateCart();
}

// Открытие/закрытие корзины
function toggleCart() {
    document.getElementById("cart").classList.toggle("open");
}

// Включение кнопок "Добавить в корзину"
document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".product button").forEach(btn => {
        btn.addEventListener("click", e => {
            let card = e.target.parentElement;
            let name = card.querySelector("h2").innerText;
            let price = parseFloat(card.querySelectorAll("p")[1].innerText.replace("$", ""));

            addToCart(name, price);
        });
    });

    // Открыть форму оформления заказа
    document.querySelector(".checkout-btn").addEventListener("click", () => {
        document.getElementById("checkout-modal").classList.add("open");
    });

    // Закрыть форму
    document.getElementById("close-checkout").addEventListener("click", () => {
        document.getElementById("checkout-modal").classList.remove("open");
    });

    // Подтвердить заказ
    document.getElementById("send-order").addEventListener("click", () => {
        let name = document.getElementById("customer-name").value;
        let phone = document.getElementById("customer-phone").value;
        let address = document.getElementById("customer-address").value;

        if (name === "" || phone === "" || address === "") {
            alert("Пожалуйста, заполните все поля!");
            return;
        }

        alert("Спасибо! Ваш заказ принят.\nМы свяжемся с вами по телефону.");

        // Очистка корзины
        cart = [];
        totalPrice = 0;
        updateCart();
        document.getElementById("cart-count").innerText = 0;

        // Закрыть окно
        document.getElementById("checkout-modal").classList.remove("open");
    });
});
